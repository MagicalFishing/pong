let logger = null
let store = null

const css_wh = `
.whdesc {
    font-family: Verdana;
}
`

module.exports = {
    title: "Pong",
    summary: "A port of Straker's HTML Pong for TUHC.",
    author: "MagicalFishing (<a href='https://magicalfishing.neocities.org'></a>)",

    description: `<p>This mod adds a playable Pong, Heretic and Hexen to the Unofficial Homestuck Collection, launchable from the home screen.</p>
	
	<ol>
	<li>Pong by Atari</li>
	<li>Original Source Code by Straker</li>
	<li>Ported to TUHC by MagicalFishing</li>
	</ol>`,

    computed(api){

        logger = api.logger
        store = api.store

        store.set("filetype", store.get("filetype", "html"))

        computed = { 
            styles: []
        }

        computed.styles.push(
            {body: css_wh}
        )

        return computed
    },
	
	edit(archive) {
            archive.tweaks.modHomeRowItems.push({
                href: "/page/Pong/m=assets%3A%2F%2Fmods%2Fpong%2Fhtml%2Fpong.html/b=|CONTROLS|<br><br>LEFT PADDLE - WASD<br>RIGHT PADDLE - ARROW KEYS",
                thumbsrc: "/mods/pong/img/logo.png",
                title: 'Pong',
                description: `Pong is a table tennis–themed twitch arcade sports video game, manufactured by Atari and originally released on 29 November 1972.`
            })
	},

}